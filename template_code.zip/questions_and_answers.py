from cbl import *
ques = ask("QUESTION: ")
if ques == "JEFF":
    showText("Hi Jeff")
else:
    showText("Idk who you are...")
