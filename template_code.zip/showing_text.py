from cbl import *
showText("Hello world")
