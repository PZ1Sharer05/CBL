word = "mojave"
word.split()
reverse_word = word[::-1]
print (reverse_word)
