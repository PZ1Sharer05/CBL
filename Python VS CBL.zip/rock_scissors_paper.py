from cbl import *

choices = ["Scissors", "Paper", "Rock"]
showText("Rock, Scissors, Paper Game")
showText("By Jeff")
def play():
    playerScore = 0
    computerScore = 0
    showText ("Play!")
    choice = ask("Play as: ")
    while choice != "":
        choice = ask("What to play as: ")
        computerChoice = randomTakeFromArray(choices)
        showText(computerChoice)
        if choice == "Scissors" and computerChoice == "Paper":
            playerScore += 1
            showText("You win!!!")
        elif choice == "Paper" and computerChoice == "Rock":
            playerScore += 1
            showText("You win!!!")
        elif choice == "Rock" and computerChoice == "Scissors":
            playerScore += 1
            showText("You win!!!")
        if choice == "Paper" and computerChoice == "Scissors":
            showText("You lost!!!")
            computerScore += 1
        elif choice == "Rock" and computerChoice == "Paper":
            showText("You lost!!!")
            computerScore += 1
        elif choice == "Scissors" and computerChoice == "Rock":
            showText("You lost!!!")
            computerScore += 1
        elif choice == computerChoice:
            showText ("Tie!!!")
    showText (playerScore)
    showText (computerScore)
    if playerScore > computerScore:
        showText ("You win!")
    else:
        showText ("Computer wins")
menu = ask("Options\nPlay\nAbout\nOption: ")
if menu == 'Play':
    play()
elif menu == 'About':
    showText ("2019 by Jeff Sharer a.k.a CS Club")
    showText ("Made for a tutorial video in CS Club")
    showText ("Simple and fun game inspired by my friend")
