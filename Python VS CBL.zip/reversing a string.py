from cbl import *
showText(reverse("reversing a string is easier than ever"))
